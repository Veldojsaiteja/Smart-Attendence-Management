import cv2
import numpy as np
import face_recognition
import os
from datetime import datetime
from tkinter import *
from PIL import ImageTk, Image  # file upload purpose
from tkinter import filedialog, messagebox  #  file upload purpose
from functools import partial
import csv
import sys
import subprocess, shutil


def functionCall():
    path = "C:\\New_folder\\masab_tank\\facialRecognitionProject\\AttendencePics"
    images = []
    classNames = []
    myList = os.listdir(path)
    print(myList)
    for cl in myList:
        curImg = cv2.imread(f'{path}/{cl}')
        images.append(curImg)
        classNames.append(os.path.splitext(cl)[0])
    print(classNames)
    print("Reading Face encodings\nLoading...")
 
    def markAttendance(name):
        with open("C:\\New_folder\\masab_tank\\facialRecognitionProject\\Attendence.csv","r+") as f:
            myDataList = f.readlines()
            nameList = []
            for line in myDataList:
                entry = line.split(',')
                nameList.append(entry[0])
            if name not in nameList:
                dtString = datetime.now().strftime('%H:%M:%S')
                f.writelines(f'\n{name},{dtString}')
 

    def findEncodings(images):
        r = 0
        encodeList = []
        for img in images:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            encode = face_recognition.face_encodings(img)
            if not len(encode):
                #print(classNames[r])
                messagebox.showwarning( "error while encoding",classNames[r] +".jpg --> image cannot be encoded(face is not detected), deleting the image!!")
                os.remove("C:\\New_folder\\masab_tank\\facialRecognitionProject\\AttendencePics\\"+classNames[r]+".jpg")
                del classNames[r]
                print(classNames)
                continue
            else:
                encode = face_recognition.face_encodings(img)[0]
            encodeList.append(encode)
            r = r + 1
        return encodeList

    encodeListKnown = findEncodings(images)
    print(len(encodeListKnown))
    #print(len(findEncodings(images)))
    print("encoding of the images completed successfully!!")

    cap = cv2.VideoCapture(0)
    i = 0
    while i < 2:
        success, img = cap.read()
        #img = captureScreen()
        imgS = cv2.resize(img,(0,0),None,0.25,0.25)
        imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)
 
        facesCurFrame = face_recognition.face_locations(imgS)
        encodesCurFrame = face_recognition.face_encodings(imgS,facesCurFrame)
 
        for encodeFace,faceLoc in zip(encodesCurFrame,facesCurFrame):
            matches = face_recognition.compare_faces(encodeListKnown,encodeFace)
            faceDis = face_recognition.face_distance(encodeListKnown,encodeFace)
            print(faceDis)
            matchIndex = np.argmin(faceDis)
 
            if faceDis[matchIndex]< 0.50:
                name = classNames[matchIndex].upper()
                i += 1
                markAttendance(name)
            else:
                name = 'Unknown'

            print(name)
            y1,x2,y2,x1 = faceLoc
            y1, x2, y2, x1 = y1*4,x2*4,y2*4,x1*4
            cv2.rectangle(img,(x1,y1),(x2,y2),(0,255,0),2)
            cv2.rectangle(img,(x1,y2-35),(x2,y2),(0,255,0),cv2.FILLED)
            cv2.putText(img,name,(x1+6,y2-6),cv2.FONT_HERSHEY_COMPLEX,1,(255,255,255),2)  
        cv2.imshow('OUTPUT',img)
        cv2.waitKey(1)
        
    cv2.destroyAllWindows()
    messagebox.showinfo("showinfo", name+" , your attendence has been marked successfully!!")
        #----------------------------------Tkinter Code --------------------------------------#



def openfn():
    filename = filedialog.askopenfilename(title='open')
    return filename

def save(source):
    destfile = "C:\\New_folder\\masab_tank\\facialRecognitionProject\\AttendencePics"
    source1 = source.index('.', -8, -1)
    pathmain = source[0:source1]+".jpg"
    ConvertToJPG = Image.open(source)
    Con = ConvertToJPG.convert("RGB")
    Con.save(pathmain)
    shutil.copy(pathmain, destfile)
    messagebox.showinfo("Uploaded..","Your photo has been uploaded successfully!!")

def open_img(root):
    root.destroy()
    window = Tk()
    window.iconbitmap(r'C:\New_folder\masab_tank\facialRecognitionProject\pythonenv\ProjectIcon.ico')
    
    window_height = 420
    window_width = 400

    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()

    x_cordinate = int((screen_width/2) - (window_width/2))
    y_cordinate = int((screen_height/2) - (window_height/2))

    window.geometry("{}x{}+{}+{}".format(window_width, window_height, x_cordinate, y_cordinate))
    #window.geometry("400x420")
    window.resizable(0,0)
    username = StringVar()
    password = StringVar()
    username.set("admin")
    password.set("admin")
    window.configure(bg="#1D1D1D")
    def call():
        x = openfn()
        print(x)
        img = Image.open(x)
        resized = img.resize((220, 220), Image.ANTIALIAS)
        final_resized_image = ImageTk.PhotoImage(resized)
        panel = Label(window , image=final_resized_image)
        panel.image = final_resized_image
        panel.place(x = 90, y = 90)
        Button(window , text = "Upload", command = lambda : save(x), bg = "#f59f02", font = ('Futura',15) ).place(x = 150, y = 325)
       # Button(window , text = "Close", command = lambda : close(window), bg = "#DDAF94", font = ('Futura',15) ).place(x = 210, y = 300)

    BackButton2 = Button(window , text = "Back" , command = lambda : modification(window, username, password) , height = 1, width = 10, bg = "#f59f02", font = ('Futura',10)).place(x = 0, y = 0)
    a = Button(window, text = "Please select the image", command = call, height = 1, width = 20, bg = "#f59f02", font = ('Futura',15)).place(x = 85, y = 40)
    notePoint = Label(window, text = "Note : The filename of an image should be with \n'StudentName'.'extension'", bg = "#1D1D1D",fg="#f59f02", font = ('Futura',13)).place(x = 10, y = 370)

def clear():
    filename = "C:\\New_folder\\masab_tank\\facialRecognitionProject\\Attendence.csv"
    # opening the file with w+ mode truncates the file
    messagebox.askquestion("Clear AttendenceList..", "Are you sure to clear the attendence list?")
    f = open(filename, "w+")
    messagebox.showinfo("Sucessfully", "you have successfully cleared the AttendenceList!!")
    f.close()
def Openattendence():
    os.startfile("C:\\New_folder\\masab_tank\\facialRecognitionProject\\Attendence.csv")


def StudentList(root):
    root.destroy()
    win1 = Tk()
    
    window_height = 400
    window_width = 400

    screen_width = win1.winfo_screenwidth()
    screen_height = win1.winfo_screenheight()

    x_cordinate = int((screen_width/2) - (window_width/2))
    y_cordinate = int((screen_height/2) - (window_height/2))

    win1.geometry("{}x{}+{}+{}".format(window_width, window_height, x_cordinate, y_cordinate))
    #win1.geometry('400x400')
    win1.title("AttendenceList")
    win1.iconbitmap(r'C:\New_folder\masab_tank\facialRecognitionProject\pythonenv\ProjectIcon.ico')
    win1.configure(bg = "#1D1D1D")
    win1.resizable(0,0)
    username = StringVar()
    password = StringVar()
    username.set("admin")
    password.set("admin")
    BackButton3 = Button(win1 , text = "Back" , command = lambda : modification(win1, username, password) , height = 1, width = 10, bg = "#f9c567", font = ('Futura',10)).place(x = 0, y = 0)
    nameHeading = Label(win1, text = "Student Name", bg = "#f9c567", font = ('Futura',13,'bold')).place(x = 70, y = 60)
    time = Label(win1, text = "Attendent Time", bg = "#f9c567", font = ('Futura',13,'bold')).place(x = 230, y = 60)
    listbox = Listbox(win1, height = 10, width = 20, bg = "#f9c567", font = ('Futura',12, 'bold'), activestyle = None)
    listbox1 = Listbox(win1, height = 10, width = 15, bg = "#f9c567", font = ('Futura',12, 'bold'), activestyle = None)
    listbox.config(highlightbackground = "black")
    listbox1.config(highlightbackground = "black")
    with open("C:\\New_folder\\masab_tank\\facialRecognitionProject\\Attendence.csv", newline='') as f:
        reader = csv.reader(f)
        data = list(reader)
        #print(data)
    divider = "___________________________________________"
    for j in range(len(data)-1):
        print(len(data))
        listbox.insert(END, data[j+1][0])
        listbox.insert(END, divider)
    listbox.place(x = 35, y = 90)
    for j in range(len(data)-1):
        listbox1.insert(END, data[j+1][1])
        listbox1.insert(END, divider)
    listbox1.place(x = 219, y = 90)
    if(len(data)==0):
        present_value = 0
    else:
        present_value = len(data)-1
    list_files = os.listdir("C:\\New_folder\\masab_tank\\facialRecognitionProject\\AttendencePics") # dir is your directory path
    number_files = len(list_files)
    total = Label(win1, text = "Total :", bg = "#f9c567", font = ('Futura',13, 'bold')).place(x = 60, y = 300)
    total_val = Label(win1, text = number_files, bg = "#1D1D1D", fg="#f59f02", font = ('Futura',13, 'bold')).place(x = 125, y = 300)
    Present = Label(win1, text = "Present :", bg = "#f9c567", font = ('Futura',13, 'bold')).place(x = 240, y = 300)
    present_val = Label(win1, text = present_value,bg = "#1D1D1D", fg="#f59f02", font = ('Futura',13, 'bold')).place(x = 330, y = 300)
    clearButton = Button(win1 , text = "Clear All" , command = lambda : clear() , height = 1, width = 15, bg = "#f9c567", font = ('Futura',13)).place(x = 50, y = 340)
    attend = Button(win1 , text = "Open in folder" , command = lambda : Openattendence() , height = 1, width = 15, bg = "#f9c567", font = ('Futura',13)).place(x = 220, y = 340)


def modification(root, user, passw):
    if(user.get()=="admin" and passw.get()=="admin"):
        root.destroy()
        sample = Tk()
        
        window_height = 400
        window_width = 400

        screen_width = sample.winfo_screenwidth()
        screen_height = sample.winfo_screenheight()

        x_cordinate = int((screen_width/2) - (window_width/2))
        y_cordinate = int((screen_height/2) - (window_height/2))
        sample.geometry("{}x{}+{}+{}".format(window_width, window_height, x_cordinate, y_cordinate))
        sample.iconbitmap(r'C:\New_folder\masab_tank\facialRecognitionProject\pythonenv\ProjectIcon.ico')
        #sample.geometry('400x400')
        sample.configure(bg="#1D1D1D")
        sample.title("Faculty Accessable Tools")
        sample.resizable(0,0)
        BackButton2 = Button(sample , text = "Goto Main" , command = lambda : main(sample) , height = 1, width = 10, bg = "#f59f02", font = ('Futura',10)).place(x = 0, y = 0)
        AddStudent = Button(sample, text = "Add New Student", command = lambda : open_img(sample), height = 1, width = 18, bg = "#f59f02", font = ('Futura',15)).place(x = 90, y = 100)
        AttendenceList = Button(sample, text = "Student AttendenceList", command = lambda : StudentList(sample),height = 1, width = 22, bg = "#f59f02", font = ('Futura',15)).place(x = 70, y = 200)
    else:
        root.destroy()
        useless1 = Tk()
        FVer(useless1, "Note : Invalid Username or Password!!")

def FVer(root, err):
    root.destroy()
    newWindow = Tk()

    window_height = 400
    window_width = 400

    screen_width = newWindow.winfo_screenwidth()
    screen_height = newWindow.winfo_screenheight()

    x_cordinate = int((screen_width/2) - (window_width/2))
    y_cordinate = int((screen_height/2) - (window_height/2))
    newWindow.geometry("{}x{}+{}+{}".format(window_width, window_height, x_cordinate, y_cordinate))
    newWindow.iconbitmap(r'C:\New_folder\masab_tank\facialRecognitionProject\pythonenv\ProjectIcon.ico')
    #newWindow.geometry('400x400')
    newWindow.configure(bg = "#1D1D1D")
    newWindow.title("Faculty Authentication")
    newWindow.resizable(0,0)
    username = StringVar()
    password = StringVar()
    BackButton1 = Button(newWindow , text = "Back" , command = lambda : main(newWindow) , height = 1, width = 10, bg = "#f59f02", font = ('Futura',10)).place(x = 0, y = 0)
    headingLabel = Label(newWindow, text = "Login Here", bg = "#f59f02", font = ('Futura',17,'bold')).place(x = 135, y = 40)
    usernameLabel = Label(newWindow, text = "Username", bg = "#f59f02", font = ('Futura',13)).place(x = 70, y = 102)
    usernameEntry = Entry(newWindow, textvariable = username, width = 20).place(x = 160, y = 102)
    PasswordLabel = Label(newWindow, text = "Password", bg = "#f59f02", font = ('Futura',13)).place(x = 70, y = 180)
    PasswordEntry = Entry(newWindow, textvariable = password, width = 20, show = '*').place(x = 160, y = 180)
    ErrorLabel = Label(newWindow, text = ""+err, font = ('Futura',13), fg = "red", bg = "#1D1D1D").place(x = 70, y = 225)
    Submit = Button(newWindow, text = "Submit", command = lambda: modification(newWindow, username, password), height = 1, width = 15, bg = "#f59f02", font = ('Futura',13)).place(x = 130, y = 280)

def exitfn(closing):
    closing.destroy()

def main(root):
    root.destroy()
    tkwindow = Tk()
    window_height = 400
    window_width = 400

    screen_width = tkwindow.winfo_screenwidth()
    screen_height = tkwindow.winfo_screenheight()

    x_cordinate = int((screen_width/2) - (window_width/2))
    y_cordinate = int((screen_height/2) - (window_height/2))
    tkwindow.geometry("{}x{}+{}+{}".format(window_width, window_height, x_cordinate, y_cordinate))
    tkwindow.iconbitmap(r'C:\New_folder\masab_tank\facialRecognitionProject\pythonenv\ProjectIcon.ico')
    #tkwindow.geometry('400x400')
    tkwindow.configure(bg="#1D1D1D") 
    tkwindow.title('ATTENDENCE MANAGEMENT')
    tkwindow.resizable(0,0)
    Heading = Label(tkwindow, text="College Attendence Management", bg = "#f59f02", font = ('Futura',16)).place(x = 50, y = 0)
    Faculty = Button(tkwindow, text="Faculty", command=lambda : FVer(tkwindow, ""),height = 1, width = 16, bg = "#f59f02", font = ('Futura',16)).place(x = 90, y = 100)
    Attendence = Button(tkwindow, text="Attendence", command = functionCall,height = 1, width = 16, bg = "#f59f02", font = ('Futura',16)).place(x = 90, y = 200)
    Close = Button(tkwindow, text="Close", command = lambda : exitfn(tkwindow),height = 1, width = 8, bg = "#CE2424", font = ('Futura',16)).place(x = 140, y =300)
    tkwindow.mainloop()

Main_Window = Tk()
main(Main_Window)